# URWalking
DEZ Bilder Android App
hier können neue Fotos vom DEZ Regensburg gemacht werden
und auch bestehende bewertet werden.
Dabei können Punkte gesammelt werden.
